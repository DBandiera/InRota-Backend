import { z } from "zod";

export const installationId = z.string().uuid();

export const createChallengeSchema = z.object({
  installationId
});

export const googleAuthSchema = z.object({
  challengeId: z.string().uuid(),
  googleIdToken: z.string().min(100),
  devicePublicKey: z.string().min(100).max(2_000),
  deviceSignature: z.string().min(32).max(256),
  integrityToken: z.string().min(100).optional()
});

export const registerPhoneSchema = z.object({
  phone: z.string().min(8).max(30)
});

export const refreshSchema = z.object({
  refreshToken: z.string().min(40),
  timestamp: z.number().int().positive(),
  deviceSignature: z.string().min(32).max(256)
});
